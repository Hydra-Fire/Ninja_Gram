const { resolve } = require('path');

module.exports = {
  resolve: {
    alias: {
      '@': resolve('app'),
    },
  },
};
