# flake8: noqa

CAPTIONS = {
    "01.jpg": "I'm the caption of #horizontal #pic 01 that will be resized "
    + "and cropped, with a mention to @maxdevblock",
    "02.jpg": "I'm the caption of #vertical #pic 02 that will be resized and"
    + " cropped, with a mention to @maxdevblock",
}
