export { default } from './Instabot';
