from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from private_instagram_sdk.api.Auth import AuthApi
from private_instagram_sdk.api.User import UserApi
