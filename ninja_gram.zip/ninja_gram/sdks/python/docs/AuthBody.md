# AuthBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ig_sig_key_version** | **** |  | [optional] 
**signed_body** | **** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

